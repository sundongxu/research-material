Sepia community test lab
========================

The Ceph community maintains a test lab that is open to active
contributors to the Ceph project.  Please see the `Sepia repository`_ for more
information.

.. _Sepia repository: https://github.com/ceph/sepia

