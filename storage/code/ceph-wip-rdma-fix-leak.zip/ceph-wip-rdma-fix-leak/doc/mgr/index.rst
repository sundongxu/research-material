

===================
Ceph Manager Daemon
===================

The :term:`Ceph Manager` daemon (ceph-mgr) runs alongside monitor daemons,
to provide additional monitoring and interfaces to external monitoring
and management systems.

.. toctree::
    :maxdepth: 1

    Installation and Configuration <administrator>
    Writing plugins <plugins>

